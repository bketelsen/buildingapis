This solution builds on exercise 08 by adding some middleware using only Go's standard library
