This solution builds on exercise 10 by replacing the standard lib mux with Gorilla's mux.
