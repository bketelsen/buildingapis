This folder contains an API written exclusively in Go's standard library.
