package cli

import (
	"encoding/json"
	"fmt"
	"github.com/bketelsen/buildingapis/workshop/service/client"
	"github.com/goadesign/goa"
	goaclient "github.com/goadesign/goa/client"
	"github.com/spf13/cobra"
	"golang.org/x/net/context"
	"log"
	"os"
	"path"
	"strings"
)

type (
	// CreateCourseCommand is the command line data structure for the create action of course
	CreateCourseCommand struct {
		Payload     string
		ContentType string
		PrettyPrint bool
	}

	// DeleteCourseCommand is the command line data structure for the delete action of course
	DeleteCourseCommand struct {
		// The course ID
		ID          int
		PrettyPrint bool
	}

	// ListCourseCommand is the command line data structure for the list action of course
	ListCourseCommand struct {
		// Filter by name
		Name        string
		PrettyPrint bool
	}

	// PatchCourseCommand is the command line data structure for the patch action of course
	PatchCourseCommand struct {
		Payload     string
		ContentType string
		// The course ID
		ID          int
		PrettyPrint bool
	}

	// ShowCourseCommand is the command line data structure for the show action of course
	ShowCourseCommand struct {
		// The course ID
		ID          int
		PrettyPrint bool
	}

	// CreateRegistrationCommand is the command line data structure for the create action of registration
	CreateRegistrationCommand struct {
		Payload     string
		ContentType string
		PrettyPrint bool
	}

	// ListRegistrationCommand is the command line data structure for the list action of registration
	ListRegistrationCommand struct {
		// Filter by course
		CourseID    int
		PrettyPrint bool
	}

	// PatchRegistrationCommand is the command line data structure for the patch action of registration
	PatchRegistrationCommand struct {
		Payload     string
		ContentType string
		// The registration ID
		ID          int
		PrettyPrint bool
	}

	// ShowRegistrationCommand is the command line data structure for the show action of registration
	ShowRegistrationCommand struct {
		// The registration ID
		ID int
		// The view used to render the registration
		View        string
		PrettyPrint bool
	}

	// LoginSessionCommand is the command line data structure for the login action of session
	LoginSessionCommand struct {
		PrettyPrint bool
	}

	// DownloadCommand is the command line data structure for the download command.
	DownloadCommand struct {
		// OutFile is the path to the download output file.
		OutFile string
	}
)

// RegisterCommands registers the resource action CLI commands.
func RegisterCommands(app *cobra.Command, c *client.Client) {
	var command, sub *cobra.Command
	command = &cobra.Command{
		Use:   "create",
		Short: `create action`,
	}
	tmp1 := new(CreateCourseCommand)
	sub = &cobra.Command{
		Use:   `course ["/api/courses"]`,
		Short: `The course resource exposes the endpoints used to manage workshop courses`,
		RunE:  func(cmd *cobra.Command, args []string) error { return tmp1.Run(c, args) },
	}
	tmp1.RegisterFlags(sub, c)
	sub.PersistentFlags().BoolVar(&tmp1.PrettyPrint, "pp", false, "Pretty print response body")
	command.AddCommand(sub)
	tmp2 := new(CreateRegistrationCommand)
	sub = &cobra.Command{
		Use:   `registration ["/api/registrations"]`,
		Short: `The registration resource exposes the endpoints used to manage workshop registrations`,
		RunE:  func(cmd *cobra.Command, args []string) error { return tmp2.Run(c, args) },
	}
	tmp2.RegisterFlags(sub, c)
	sub.PersistentFlags().BoolVar(&tmp2.PrettyPrint, "pp", false, "Pretty print response body")
	command.AddCommand(sub)
	app.AddCommand(command)
	command = &cobra.Command{
		Use:   "delete",
		Short: `Delete a course`,
	}
	tmp3 := new(DeleteCourseCommand)
	sub = &cobra.Command{
		Use:   `course ["/api/courses/ID"]`,
		Short: `The course resource exposes the endpoints used to manage workshop courses`,
		RunE:  func(cmd *cobra.Command, args []string) error { return tmp3.Run(c, args) },
	}
	tmp3.RegisterFlags(sub, c)
	sub.PersistentFlags().BoolVar(&tmp3.PrettyPrint, "pp", false, "Pretty print response body")
	command.AddCommand(sub)
	app.AddCommand(command)
	command = &cobra.Command{
		Use:   "list",
		Short: `list action`,
	}
	tmp4 := new(ListCourseCommand)
	sub = &cobra.Command{
		Use:   `course ["/api/courses"]`,
		Short: `The course resource exposes the endpoints used to manage workshop courses`,
		RunE:  func(cmd *cobra.Command, args []string) error { return tmp4.Run(c, args) },
	}
	tmp4.RegisterFlags(sub, c)
	sub.PersistentFlags().BoolVar(&tmp4.PrettyPrint, "pp", false, "Pretty print response body")
	command.AddCommand(sub)
	tmp5 := new(ListRegistrationCommand)
	sub = &cobra.Command{
		Use:   `registration ["/api/registrations"]`,
		Short: `The registration resource exposes the endpoints used to manage workshop registrations`,
		RunE:  func(cmd *cobra.Command, args []string) error { return tmp5.Run(c, args) },
	}
	tmp5.RegisterFlags(sub, c)
	sub.PersistentFlags().BoolVar(&tmp5.PrettyPrint, "pp", false, "Pretty print response body")
	command.AddCommand(sub)
	app.AddCommand(command)
	command = &cobra.Command{
		Use:   "login",
		Short: `Login uses basic auth and on successful auth returns a JWT in the response "Authorization" header`,
	}
	tmp6 := new(LoginSessionCommand)
	sub = &cobra.Command{
		Use:   `session ["/api/token"]`,
		Short: `The session resource exposes the login action`,
		RunE:  func(cmd *cobra.Command, args []string) error { return tmp6.Run(c, args) },
	}
	tmp6.RegisterFlags(sub, c)
	sub.PersistentFlags().BoolVar(&tmp6.PrettyPrint, "pp", false, "Pretty print response body")
	command.AddCommand(sub)
	app.AddCommand(command)
	command = &cobra.Command{
		Use:   "patch",
		Short: `patch action`,
	}
	tmp7 := new(PatchCourseCommand)
	sub = &cobra.Command{
		Use:   `course ["/api/courses/ID"]`,
		Short: `The course resource exposes the endpoints used to manage workshop courses`,
		RunE:  func(cmd *cobra.Command, args []string) error { return tmp7.Run(c, args) },
	}
	tmp7.RegisterFlags(sub, c)
	sub.PersistentFlags().BoolVar(&tmp7.PrettyPrint, "pp", false, "Pretty print response body")
	command.AddCommand(sub)
	tmp8 := new(PatchRegistrationCommand)
	sub = &cobra.Command{
		Use:   `registration ["/api/registrations/ID"]`,
		Short: `The registration resource exposes the endpoints used to manage workshop registrations`,
		RunE:  func(cmd *cobra.Command, args []string) error { return tmp8.Run(c, args) },
	}
	tmp8.RegisterFlags(sub, c)
	sub.PersistentFlags().BoolVar(&tmp8.PrettyPrint, "pp", false, "Pretty print response body")
	command.AddCommand(sub)
	app.AddCommand(command)
	command = &cobra.Command{
		Use:   "show",
		Short: `show action`,
	}
	tmp9 := new(ShowCourseCommand)
	sub = &cobra.Command{
		Use:   `course ["/api/courses/ID"]`,
		Short: `The course resource exposes the endpoints used to manage workshop courses`,
		RunE:  func(cmd *cobra.Command, args []string) error { return tmp9.Run(c, args) },
	}
	tmp9.RegisterFlags(sub, c)
	sub.PersistentFlags().BoolVar(&tmp9.PrettyPrint, "pp", false, "Pretty print response body")
	command.AddCommand(sub)
	tmp10 := new(ShowRegistrationCommand)
	sub = &cobra.Command{
		Use:   `registration ["/api/registrations/ID"]`,
		Short: `The registration resource exposes the endpoints used to manage workshop registrations`,
		RunE:  func(cmd *cobra.Command, args []string) error { return tmp10.Run(c, args) },
	}
	tmp10.RegisterFlags(sub, c)
	sub.PersistentFlags().BoolVar(&tmp10.PrettyPrint, "pp", false, "Pretty print response body")
	command.AddCommand(sub)
	app.AddCommand(command)

	dl := new(DownloadCommand)
	dlc := &cobra.Command{
		Use:   "download [PATH]",
		Short: "Download file with given path",
		RunE: func(cmd *cobra.Command, args []string) error {
			return dl.Run(c, args)
		},
	}
	dlc.Flags().StringVar(&dl.OutFile, "out", "", "Output file")
	app.AddCommand(dlc)
}

func intFlagVal(name string, parsed int) *int {
	if hasFlag(name) {
		return &parsed
	}
	return nil
}

func float64FlagVal(name string, parsed float64) *float64 {
	if hasFlag(name) {
		return &parsed
	}
	return nil
}

func boolFlagVal(name string, parsed bool) *bool {
	if hasFlag(name) {
		return &parsed
	}
	return nil
}

func stringFlagVal(name string, parsed string) *string {
	if hasFlag(name) {
		return &parsed
	}
	return nil
}

func hasFlag(name string) bool {
	for _, arg := range os.Args[1:] {
		if strings.HasPrefix(arg, "--"+name) {
			return true
		}
	}
	return false
}

// Run makes the HTTP request corresponding to the CreateCourseCommand command.
func (cmd *CreateCourseCommand) Run(c *client.Client, args []string) error {
	var path string
	if len(args) > 0 {
		path = args[0]
	} else {
		path = "/api/courses"
	}
	var payload client.CreateCoursePayload
	if cmd.Payload != "" {
		err := json.Unmarshal([]byte(cmd.Payload), &payload)
		if err != nil {
			return fmt.Errorf("failed to deserialize payload: %s", err)
		}
	}
	logger := goa.NewLogger(log.New(os.Stderr, "", log.LstdFlags))
	ctx := goa.WithLogger(context.Background(), logger)
	resp, err := c.CreateCourse(ctx, path, &payload, cmd.ContentType)
	if err != nil {
		goa.LogError(ctx, "failed", "err", err)
		return err
	}

	goaclient.HandleResponse(c.Client, resp, cmd.PrettyPrint)
	return nil
}

// RegisterFlags registers the command flags with the command line.
func (cmd *CreateCourseCommand) RegisterFlags(cc *cobra.Command, c *client.Client) {
	cc.Flags().StringVar(&cmd.Payload, "payload", "", "Request body encoded in JSON")
	cc.Flags().StringVar(&cmd.ContentType, "content", "", "Request content type override, e.g. 'application/x-www-form-urlencoded'")
}

// Run makes the HTTP request corresponding to the DeleteCourseCommand command.
func (cmd *DeleteCourseCommand) Run(c *client.Client, args []string) error {
	var path string
	if len(args) > 0 {
		path = args[0]
	} else {
		path = fmt.Sprintf("/api/courses/%v", cmd.ID)
	}
	logger := goa.NewLogger(log.New(os.Stderr, "", log.LstdFlags))
	ctx := goa.WithLogger(context.Background(), logger)
	resp, err := c.DeleteCourse(ctx, path)
	if err != nil {
		goa.LogError(ctx, "failed", "err", err)
		return err
	}

	goaclient.HandleResponse(c.Client, resp, cmd.PrettyPrint)
	return nil
}

// RegisterFlags registers the command flags with the command line.
func (cmd *DeleteCourseCommand) RegisterFlags(cc *cobra.Command, c *client.Client) {
	var id int
	cc.Flags().IntVar(&cmd.ID, "id", id, `The course ID`)
}

// Run makes the HTTP request corresponding to the ListCourseCommand command.
func (cmd *ListCourseCommand) Run(c *client.Client, args []string) error {
	var path string
	if len(args) > 0 {
		path = args[0]
	} else {
		path = "/api/courses"
	}
	logger := goa.NewLogger(log.New(os.Stderr, "", log.LstdFlags))
	ctx := goa.WithLogger(context.Background(), logger)
	resp, err := c.ListCourse(ctx, path, stringFlagVal("name", cmd.Name))
	if err != nil {
		goa.LogError(ctx, "failed", "err", err)
		return err
	}

	goaclient.HandleResponse(c.Client, resp, cmd.PrettyPrint)
	return nil
}

// RegisterFlags registers the command flags with the command line.
func (cmd *ListCourseCommand) RegisterFlags(cc *cobra.Command, c *client.Client) {
	var name string
	cc.Flags().StringVar(&cmd.Name, "name", name, `Filter by name`)
}

// Run makes the HTTP request corresponding to the PatchCourseCommand command.
func (cmd *PatchCourseCommand) Run(c *client.Client, args []string) error {
	var path string
	if len(args) > 0 {
		path = args[0]
	} else {
		path = fmt.Sprintf("/api/courses/%v", cmd.ID)
	}
	var payload client.PatchCoursePayload
	if cmd.Payload != "" {
		err := json.Unmarshal([]byte(cmd.Payload), &payload)
		if err != nil {
			return fmt.Errorf("failed to deserialize payload: %s", err)
		}
	}
	logger := goa.NewLogger(log.New(os.Stderr, "", log.LstdFlags))
	ctx := goa.WithLogger(context.Background(), logger)
	resp, err := c.PatchCourse(ctx, path, &payload, cmd.ContentType)
	if err != nil {
		goa.LogError(ctx, "failed", "err", err)
		return err
	}

	goaclient.HandleResponse(c.Client, resp, cmd.PrettyPrint)
	return nil
}

// RegisterFlags registers the command flags with the command line.
func (cmd *PatchCourseCommand) RegisterFlags(cc *cobra.Command, c *client.Client) {
	cc.Flags().StringVar(&cmd.Payload, "payload", "", "Request body encoded in JSON")
	cc.Flags().StringVar(&cmd.ContentType, "content", "", "Request content type override, e.g. 'application/x-www-form-urlencoded'")
	var id int
	cc.Flags().IntVar(&cmd.ID, "id", id, `The course ID`)
}

// Run makes the HTTP request corresponding to the ShowCourseCommand command.
func (cmd *ShowCourseCommand) Run(c *client.Client, args []string) error {
	var path string
	if len(args) > 0 {
		path = args[0]
	} else {
		path = fmt.Sprintf("/api/courses/%v", cmd.ID)
	}
	logger := goa.NewLogger(log.New(os.Stderr, "", log.LstdFlags))
	ctx := goa.WithLogger(context.Background(), logger)
	resp, err := c.ShowCourse(ctx, path)
	if err != nil {
		goa.LogError(ctx, "failed", "err", err)
		return err
	}

	goaclient.HandleResponse(c.Client, resp, cmd.PrettyPrint)
	return nil
}

// RegisterFlags registers the command flags with the command line.
func (cmd *ShowCourseCommand) RegisterFlags(cc *cobra.Command, c *client.Client) {
	var id int
	cc.Flags().IntVar(&cmd.ID, "id", id, `The course ID`)
}

// Run downloads files with given paths.
func (cmd *DownloadCommand) Run(c *client.Client, args []string) error {
	var (
		fnf func(context.Context, string) (int64, error)
		fnd func(context.Context, string, string) (int64, error)

		rpath   = args[0]
		outfile = cmd.OutFile
		logger  = goa.NewLogger(log.New(os.Stderr, "", log.LstdFlags))
		ctx     = goa.WithLogger(context.Background(), logger)
		err     error
	)

	if rpath[0] != '/' {
		rpath = "/" + rpath
	}
	if rpath == "/swagger.json" {
		fnf = c.DownloadSwaggerJSON
		if outfile == "" {
			outfile = "swagger.json"
		}
		goto found
	}
	if rpath == "/swagger.yaml" {
		fnf = c.DownloadSwaggerYaml
		if outfile == "" {
			outfile = "swagger.yaml"
		}
		goto found
	}
	if strings.HasPrefix(rpath, "/swagger/") {
		fnd = c.DownloadSwagger
		rpath = rpath[9:]
		if outfile == "" {
			_, outfile = path.Split(rpath)
		}
		goto found
	}
	return fmt.Errorf("don't know how to download %s", rpath)
found:
	ctx = goa.WithLogContext(ctx, "file", outfile)
	if fnf != nil {
		_, err = fnf(ctx, outfile)
	} else {
		_, err = fnd(ctx, rpath, outfile)
	}
	if err != nil {
		goa.LogError(ctx, "failed", "err", err)
		return err
	}

	return nil
}

// Run makes the HTTP request corresponding to the CreateRegistrationCommand command.
func (cmd *CreateRegistrationCommand) Run(c *client.Client, args []string) error {
	var path string
	if len(args) > 0 {
		path = args[0]
	} else {
		path = "/api/registrations"
	}
	var payload client.CreateRegistrationPayload
	if cmd.Payload != "" {
		err := json.Unmarshal([]byte(cmd.Payload), &payload)
		if err != nil {
			return fmt.Errorf("failed to deserialize payload: %s", err)
		}
	}
	logger := goa.NewLogger(log.New(os.Stderr, "", log.LstdFlags))
	ctx := goa.WithLogger(context.Background(), logger)
	resp, err := c.CreateRegistration(ctx, path, &payload, cmd.ContentType)
	if err != nil {
		goa.LogError(ctx, "failed", "err", err)
		return err
	}

	goaclient.HandleResponse(c.Client, resp, cmd.PrettyPrint)
	return nil
}

// RegisterFlags registers the command flags with the command line.
func (cmd *CreateRegistrationCommand) RegisterFlags(cc *cobra.Command, c *client.Client) {
	cc.Flags().StringVar(&cmd.Payload, "payload", "", "Request body encoded in JSON")
	cc.Flags().StringVar(&cmd.ContentType, "content", "", "Request content type override, e.g. 'application/x-www-form-urlencoded'")
}

// Run makes the HTTP request corresponding to the ListRegistrationCommand command.
func (cmd *ListRegistrationCommand) Run(c *client.Client, args []string) error {
	var path string
	if len(args) > 0 {
		path = args[0]
	} else {
		path = "/api/registrations"
	}
	logger := goa.NewLogger(log.New(os.Stderr, "", log.LstdFlags))
	ctx := goa.WithLogger(context.Background(), logger)
	resp, err := c.ListRegistration(ctx, path, intFlagVal("course_id", cmd.CourseID))
	if err != nil {
		goa.LogError(ctx, "failed", "err", err)
		return err
	}

	goaclient.HandleResponse(c.Client, resp, cmd.PrettyPrint)
	return nil
}

// RegisterFlags registers the command flags with the command line.
func (cmd *ListRegistrationCommand) RegisterFlags(cc *cobra.Command, c *client.Client) {
	var courseID int
	cc.Flags().IntVar(&cmd.CourseID, "course_id", courseID, `Filter by course`)
}

// Run makes the HTTP request corresponding to the PatchRegistrationCommand command.
func (cmd *PatchRegistrationCommand) Run(c *client.Client, args []string) error {
	var path string
	if len(args) > 0 {
		path = args[0]
	} else {
		path = fmt.Sprintf("/api/registrations/%v", cmd.ID)
	}
	var payload client.PatchRegistrationPayload
	if cmd.Payload != "" {
		err := json.Unmarshal([]byte(cmd.Payload), &payload)
		if err != nil {
			return fmt.Errorf("failed to deserialize payload: %s", err)
		}
	}
	logger := goa.NewLogger(log.New(os.Stderr, "", log.LstdFlags))
	ctx := goa.WithLogger(context.Background(), logger)
	resp, err := c.PatchRegistration(ctx, path, &payload, cmd.ContentType)
	if err != nil {
		goa.LogError(ctx, "failed", "err", err)
		return err
	}

	goaclient.HandleResponse(c.Client, resp, cmd.PrettyPrint)
	return nil
}

// RegisterFlags registers the command flags with the command line.
func (cmd *PatchRegistrationCommand) RegisterFlags(cc *cobra.Command, c *client.Client) {
	cc.Flags().StringVar(&cmd.Payload, "payload", "", "Request body encoded in JSON")
	cc.Flags().StringVar(&cmd.ContentType, "content", "", "Request content type override, e.g. 'application/x-www-form-urlencoded'")
	var id int
	cc.Flags().IntVar(&cmd.ID, "id", id, `The registration ID`)
}

// Run makes the HTTP request corresponding to the ShowRegistrationCommand command.
func (cmd *ShowRegistrationCommand) Run(c *client.Client, args []string) error {
	var path string
	if len(args) > 0 {
		path = args[0]
	} else {
		path = fmt.Sprintf("/api/registrations/%v", cmd.ID)
	}
	logger := goa.NewLogger(log.New(os.Stderr, "", log.LstdFlags))
	ctx := goa.WithLogger(context.Background(), logger)
	resp, err := c.ShowRegistration(ctx, path, stringFlagVal("view", cmd.View))
	if err != nil {
		goa.LogError(ctx, "failed", "err", err)
		return err
	}

	goaclient.HandleResponse(c.Client, resp, cmd.PrettyPrint)
	return nil
}

// RegisterFlags registers the command flags with the command line.
func (cmd *ShowRegistrationCommand) RegisterFlags(cc *cobra.Command, c *client.Client) {
	var id int
	cc.Flags().IntVar(&cmd.ID, "id", id, `The registration ID`)
	var view string
	cc.Flags().StringVar(&cmd.View, "view", view, `The view used to render the registration`)
}

// Run makes the HTTP request corresponding to the LoginSessionCommand command.
func (cmd *LoginSessionCommand) Run(c *client.Client, args []string) error {
	var path string
	if len(args) > 0 {
		path = args[0]
	} else {
		path = "/api/token"
	}
	logger := goa.NewLogger(log.New(os.Stderr, "", log.LstdFlags))
	ctx := goa.WithLogger(context.Background(), logger)
	resp, err := c.LoginSession(ctx, path)
	if err != nil {
		goa.LogError(ctx, "failed", "err", err)
		return err
	}

	goaclient.HandleResponse(c.Client, resp, cmd.PrettyPrint)
	return nil
}

// RegisterFlags registers the command flags with the command line.
func (cmd *LoginSessionCommand) RegisterFlags(cc *cobra.Command, c *client.Client) {
}
